# Bigzero-Kuku
Website ya Kiswahili ya Bigzero Kuku — biashara ya kuku pekee.

## Kuchapisha GitHub Pages
1. Pakia `index.html` kwenye mzizi wa repository `Bigzero-Kuku`.
2. Bonyeza Commit changes.
3. Fungua Settings → Pages.
4. Chagua Deploy from a branch, branch `main`, folder `/(root)`, kisha Save.

Picha za mfano zinapakiwa kutoka Unsplash na zinahitaji intaneti. Viungo vya kuagiza vinafungua WhatsApp.
